#include <iostream>
#include "MainUI.h"
using namespace std;

int main()
{
    MainUI main;                                    //Create UI Class
    main.startUI();                                 //Start UI
    return 0;
}
