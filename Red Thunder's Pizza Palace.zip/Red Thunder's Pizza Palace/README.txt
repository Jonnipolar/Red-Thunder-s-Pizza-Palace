
						Red Thunder's Pizza Palace

1.0	Manager
1.1	Make Pizza
1.2	Make Toppings
1.3	View pizza Menu
1.4	Add other items
1.5	Add pizza Place
1.6	List of All orders checked out

2.0	Sales
2.1	Add an order
2.2	Print last orders

3.0 	Bakery
3.1	Orders in processing
3.2	Orders in progress

4.0 	Delivery
4.1	List of all orders
4.2	List of all orders done





	1.0 Manager
The manager does all admin work for the pizza place. He can make pizza, make toppings, and other items
	1.1 Make Pizza
He can Make pizza, choose toppings and name the pizza and control price
	1.2 Make toppings
He can make toppings, choose name price and choose its type (meat, cheese or vegetable)
	1.3 View Pizza menu
He can see all pizzas available
	1.4 Add other items
He can add other items, like sides, sauces and sodas
	1.5 ad pizza place
The manager can add a pizza place
	1.6 List of all orders checked out
The manager can see all orders

	2.0 Sales
The sales guy can add orders
	2.1 Add order
He can add order, add pizza with toppings or from menu